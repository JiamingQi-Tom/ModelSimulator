fprintf('** building frne mex file\n');


mex frne.c ne.c vmath.c

function y= F_dQe( q,target )
%FQ �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
y=zeros(3,1);
q1=q(1);
q2=q(2);
q3=q(3);
q4=q(4);
tx=target(1);
ty=target(2);
tz=target(3);
Cbi=[q1^2-q2^2-q3^2+q4^2 2*(q1*q2+q3*q4) 2*(q1*q3-q2*q4);
    2*(q1*q2-q3*q4) -q1^2+q2^2-q3^2+q4^2 2*(q2*q3+q1*q4);
    2*(q1*q3+q2*q4) 2*(q2*q3-q1*q4) -q1^2-q2^2+q3^2+q4^2];

y=[0 -Cbi(3,:)*target Cbi(2,:)*target;
   Cbi(3,:)*target 0 -Cbi(1,:)*target;
   -Cbi(2,:)*target Cbi(1,:)*target 0];
end


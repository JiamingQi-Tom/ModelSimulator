%%%%%%%%%%%%%%%%%%%%by gyz 20180804%%%%%%%%%%%%%%%%%%%%%%
clear
global J
J=[86.24 0 0;
    0 85.07 0;
    0 0 113.59];
q0=[0 0 0 1]';
q0=q0/norm(q0);
w0=[0 0 0]';       %%��ʼ���ٶ�
wd=[0 0 0]';
w=w0;              %Ϊ�˵�һ���ܳ��򲻱���
q=q0;
X0=[q0;w0];
X=X0;
Tar=[2;1;1];
Tar=Tar/norm(Tar);
we=w0-wd;
theta_e=defQe(q0,Tar);
u=[0 0 0]';

h=0.01;                         %%���沽��
Step_Nu=6000;                    %%%���沽��

kp=0.07;kd=0.48;
for i=1:Step_Nu
    t=i*h;
    
    u=-kd*J*we-kp*J*F_dQe(q,Tar)'*theta_e;
    d=0*0.001*[sin(0.1*t);-cos(0.1*t);sin(0.1*t)];
    %%%%%%%%%%%%%%%%%%�����������%%%%%%%%%%%%%%%%%
    k1=f(X)+g(X)*(u+d);
    k2=f(X+h/2*k1)+g(X+h/2*k1)*(u+d);
    k3=f(X+h/2*k2)+g(X+h/2*k2)*(u+d);
    k4=f(X+h*k3)+g(X+h*k3)*(u+d);
    X=X+h/6*(k1+2*k2+2*k3+k4);
    q=X(1:4);
    w=X(5:7);
    we=w-wd;
    theta_e=defQe(q,Tar);
    time_draw(1,i) = (i-1);    
    X_draw(:,i)=X;
    u_draw(:,i)=u;    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

figure('name','Quaternion')
hold on
plot(time_draw*h,X_draw(1,:),'-','LineWidth',2);
plot(time_draw*h,X_draw(2,:),'-.','LineWidth',2);
plot(time_draw*h,X_draw(3,:),'--','LineWidth',2);
plot(time_draw*h,X_draw(4,:),':','LineWidth',2);

legend('{\itq}_1','{\itq}_2','{\itq}_3','{\itq}_4','Orientation','horizental');
xlabel('{\itt}(s)','FontName','Times New Roman','FontSize',12)
ylabel('{\itq}(deg/s)','FontName','Times New Roman','FontSize',12)
set(gca,'FontName','Times New Roman','FontSize',12);
set(gcf,'position',[0,50,460,250])
% 

figure('name','anguler velocity')
hold on
plot(time_draw*h,X_draw(5,:)*180/pi,'-','LineWidth',2);
plot(time_draw*h,X_draw(6,:)*180/pi,'--','LineWidth',2);
plot(time_draw*h,X_draw(7,:)*180/pi,'-','LineWidth',2);
legend('{\it\omega}_1','{\it\omega}_2','{\it\omega}_3','Orientation','horizental');
xlabel('{\itt}(s)','FontName','Times New Roman','FontSize',12)
ylabel('{\it\omega}(deg/s)','FontName','Times New Roman','FontSize',12)
set(gca,'FontName','Times New Roman','FontSize',12);
set(gcf,'position',[0,50,460,250])
% 

figure('name','control')
hold on
plot(time_draw*h,u_draw(1,:),'-','LineWidth',2);
plot(time_draw*h,u_draw(2,:),'-.','LineWidth',2);
plot(time_draw*h,u_draw(3,:),'--','LineWidth',2);
legend('{\itu}_1','{\itu}_2','{\itu}_3','Orientation','horizental');
xlabel('{\itt}(s)','FontName','Times New Roman','FontSize',12)
ylabel('{\it\bfu}(Nm)','FontName','Times New Roman','FontSize',12)
set(gca,'FontName','Times New Roman','FontSize',12);
set(gcf,'position',[0,50,460,250])
% 
% 

